import os
import tarfile
import test_README

os.system("make tar")
os.system("make clean")
files = tarfile.open("ex1.tar")
files.extractall(path=".", members=None)

#tar
y = files.getnames()
numOfFiles = len(y)
if numOfFiles != 3:
    print "you should submit 3 files"
if "README" not in y:
    print "There is no README"
if ("osm.c" not in y) and ("osm.cpp" not in y):
    print "There is no osm file"
if "Makefile" not in y:
    print "There is no Makefile"

#readme
if "README" in y:
    x = test_README.test_README(os.getcwd())
    print x

#make
os.system("make")
z = os.listdir(os.getcwd())
if "libosm.a" not in z:
    print "There is no libosm.a after make command"

files.close()
